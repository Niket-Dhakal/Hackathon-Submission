# Instructions
To run this program, make sure you either download the zip file, and change the runtime environment to the virual environment. Or just manually set up your own virtual environment and install all the packages manually.
After that, just pull up a terminal with the virual environemtn active (I recommend command prompt, and run the command .venv\Scripts\activate.bat while being in the same directory as your .venv file)
Once you have those steps done, navigate to the testProject directory (it's named as such beacuse all the stuff we did beforehand was for testing, but eventually just evolved into our main project) and then run the command (windows only, sorry I don't know mac) "python manage.py runserver"
After doing so, follow the ip given, and if done correctly, you should have access to the website. (also please don't spam my API key, I'm broke)
Make sure to refresh the page to type in another prompt after one has been answered.

## THANK YOU!!
